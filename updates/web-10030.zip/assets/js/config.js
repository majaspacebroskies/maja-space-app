window.MAJA_CONFIG={googleClientId:"",aiEndpoint:"",aiDailyLimit:40,downloadPage:"https://safistudyspace.netlify.app/"};
